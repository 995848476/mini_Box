#include "usart.h"
#include "delay.h"
#include "sys.h"
#include "DHT11.h"
#include "led.h"
#include "bh1750.h"

int main(void)
{
//	u8 temp,humi;//��ʪ��
	u8 buf[2]={0}; //���ջ���
	u16 value;
	float light = 0.0;
	LED_Init();
	NVIC_Configuration();
	USART1_Init(9600);//��ʼ������
	SysTick_Init(72);
	DHT11_Init();
	IIC_Init();
	Init_BH1750();
	while(1)
	{		
//		DHT11_Read_Data(&temp,&humi);//��ȡ��ʪ��
//		printf("�¶ȣ�%d, ʪ�ȣ�%d%% \r\n", temp, humi);
//		GPIO_SetBits(LED_PORT,LED_PORT_Pin);
//		delay_ms(1000);
//		GPIO_ResetBits(LED_PORT,LED_PORT_Pin);
		
//		Multiple_Read_BH1750(buf);
//		value = (buf[0]<<8)+buf[1];
//		light = value/1.2;
		printf("����ǿ��Ϊ��%d\n",buf);
		delay_ms(1000);
	}
	
}


