#ifndef _LED_H
#define _LED_H

#define RCC_TIME      RCC_APB2Periph_GPIOG
#define LED_PORT      GPIOG
#define LED_PORT_Pin  GPIO_Pin_12

void LED_Init(void);

#endif

