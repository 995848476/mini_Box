#include "led.h"
#include "sys.h"

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_TIME, ENABLE); //ʹ��PE �˿�ʱ��
	
	//����IO��ģʽ
	GPIO_InitStructure.GPIO_Pin=LED_PORT_Pin;//PE5/PE6
	GPIO_InitStructure.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;//�������
	GPIO_Init(LED_PORT, &GPIO_InitStructure);
	GPIO_ResetBits(LED_PORT,LED_PORT_Pin); //Ĭ�Ϲر�
}

