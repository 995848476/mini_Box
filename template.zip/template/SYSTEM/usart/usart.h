#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

int fputc(int ch,FILE *p);//�ض�����

void USART1_Init(u32 bound);

#endif


